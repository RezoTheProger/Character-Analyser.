using System.Drawing;
using System.Text;
using System.Text.RegularExpressions;
using OfficeOpenXml;


public class Program
{
    private static  List<char> Chars = new();
    private static string color = "";

    private static void Main(string[] args)
    {
        Console.InputEncoding = Encoding.Unicode;
        Console.OutputEncoding = Encoding.Unicode;


        Console.Write("Which characters to find (put in spaces to separate between characters) :");
        string? Output = Console.ReadLine();
        while(Output == "")
        {
            
            Console.Write("Characters can't be null, please input real characters :");
             Output = Console.ReadLine();
            

        }
        AddToArray(Output);

        Console.Write("Which color to use (HEX format)  :");
         color = Console.ReadLine();
        while (!IsValidHexaCode(color))
        {
            Console.Write("This color doesn't exist, please put in a real HEX value   :");
             color = Console.ReadLine();
        }

       
       
        Console.Write("Your text: ");
        string? Input = Console.ReadLine();
        while (Input == "")
        {
            Console.Write("Your text can't be null, please input text normally: ");
             Input = Console.ReadLine();
        }

        Input = Input.Replace(" ", null);
        Load(Input);
        


    }


    private static void AddToArray(string? Input)
    {
       foreach (char c in Input)
        {
            if (c == ' ') continue;
            Chars.Add(c);
        }
    }


    private static void Load(string Input)
    {



        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
        ExcelPackage ExcelPkg = new();
        ExcelWorksheet worksheet = ExcelPkg.Workbook.Worksheets.Add("Sheet1");



       

        
        double ceiling = Math.Ceiling(Math.Sqrt(Input.Length));
        int x = 0;
        for (int i = 0; i < ceiling; i++)
        {
            for (int j = 0; j < ceiling; j++)
            {
                
                if (x == Input.Length) break;
                string coloring = Checker(Input[x]);

                worksheet.Row(i + 1).Height = 20;
                worksheet.Cells[j + 1, i + 1].Value = Input[x].ToString();
                if (coloring != null)
                {
                    Color colFromHex = ColorTranslator.FromHtml(coloring);
                    worksheet.Cells[j + 1, i + 1].Style.Fill.PatternType = OfficeOpenXml.Style.ExcelFillStyle.Solid;
                    worksheet.Cells[j + 1, i + 1].Style.Fill.BackgroundColor.SetColor(colFromHex);
                    Console.WriteLine("Imported successfuly the letter: " + Input[x].ToString() + " With color: " + color);
                }
                else
                {
                    Console.WriteLine("Imported successfuly the letter: " + Input[x].ToString());
                }
                x++;
            }
        }

        string fileName = "Analyse.csv";
        if (File.Exists( fileName)) File.Delete( fileName);
        FileStream fileExcel = File.Create( fileName);
        fileExcel.Close();

        File.WriteAllBytes( fileName, ExcelPkg.GetAsByteArray());
        ExcelPkg.Dispose();
        Console.WriteLine("file was created successfully");





    }
    
    private static bool IsValidHexaCode(string? str)
    {
        
        Regex hexaCode = new Regex(@"^#([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$");

        return hexaCode.IsMatch(str);
    }



    private static string? Checker(char Character)
    {

        for(int i = 0 ; i < Chars.Count ; i++)
        {
            if (Chars[i] != null && Character == Chars[i]) return color;
            else continue;
        }
        return null;
    }

}
